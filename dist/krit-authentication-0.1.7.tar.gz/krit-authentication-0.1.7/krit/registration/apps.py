from django.apps import AppConfig as BaseAppConfig


class AppConfig(BaseAppConfig):
    name = 'krit.registration'
    label = 'krit_registration'
